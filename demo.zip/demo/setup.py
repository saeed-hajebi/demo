from setuptools import find_packages, setup
import toml

project_settings_dict = toml.load("pyproject.toml")

setup(
    name='delme',
    packages=find_packages(exclude=('tests', 'docs')),
    version=project_settings_dict['version'],
    description='A short description of the project.',
    author='Your name (or your team)',
    license='',
)
