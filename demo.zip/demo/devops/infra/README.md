How to setup infrastructre for the project on PPD & Prod
--------------------------------------------------------
