import re  # regex library
import pandas as pd


def preprocessor(text):
    text = re.sub("<[^>]*>", "", text)  # Effectively removes HTML markup tags
    emoticons = re.findall("(?::|;|=)(?:-)?(?:\)|\(|D|P)", text)
    text = re.sub("[\W]+", " ", text.lower()) + " ".join(emoticons).replace(
        "-", ""
    )
    return text


# X, y = (data["Message"].apply(preprocessor), data["Category"])


def preprocess(data: pd.DataFrame) -> pd.DataFrame:
    data["Message"] = data["Message"].apply(preprocessor)
    return data
