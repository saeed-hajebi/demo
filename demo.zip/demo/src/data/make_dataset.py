import pandas as pd

from sklearn.model_selection import train_test_split

# from config.config import *
# DATA_FILE = "../../data/raw/spam_data.csv"

# Read the Data
def make_dataset(data_file) -> pd.DataFrame:
    # dataset = pd.read_csv(DATASET_DIR / "spam_data.csv")
    dataset = pd.read_csv(data_file)
    return dataset


def split_data(X: pd.DataFrame, y: pd.DataFrame):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )
    return (X_train, X_test, y_train, y_test)
