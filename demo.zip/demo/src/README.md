How to run code
---------------
