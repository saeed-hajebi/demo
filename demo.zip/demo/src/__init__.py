import pathlib
import toml

PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

project_settings_dict = toml.load(PROJECT_ROOT / "pyproject.toml")

__version__ = project_settings_dict["version"]
