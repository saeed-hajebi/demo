import pathlib
import sys
import joblib
import logging


from data.make_dataset import make_dataset, split_data
from data.preprocessing import preprocess
from features.build_features import *
from models.train_model import train_model
from models.predict_model import predict_model
from utils.utils import print_classification_report
from config.config import S3_DATA_FILE, MODEL_FILE

PROJECT_ROOT = pathlib.Path(__file__).resolve().parent
sys.path.append(PROJECT_ROOT)


def get_logger(name):
    log = logging.getLogger(name)
    log.setLevel(logging.INFO)
    log_handler = logging.StreamHandler(sys.stdout)
    log_handler.setFormatter(
        logging.Formatter(
            "%(levelname)s - %(asctime)s -  %(module)s - %(funcName)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    log.addHandler(log_handler)
    return log


logger = get_logger(__name__)


def main():
    logger.info("########## Starting #########")

    logger.info("########## Making Dataset #########")
    data = make_dataset(S3_DATA_FILE)

    # preprocessing here
    logger.info("########## Preprocessing #########")
    data = preprocess(data)

    logger.info("########## Train/Test Split #########")
    X, y = (data["Message"], data["Category"])

    X_train, X_test, y_train, y_test = split_data(X, y)

    logger.info("########## Training #########")
    model = train_model(X_train, y_train)

    logger.info("########## Saving Model Object to File #########")
    joblib.dump(model, MODEL_FILE)

    logger.info("########## Loading Model Object from File #########")
    serving_model = joblib.load(MODEL_FILE)

    logger.info("########## Prediction #########")
    y_pred = predict_model(serving_model, X_test)

    logger.info("########## Print Results #########")
    print_classification_report(y_test, y_pred)


if __name__ == "__main__":
    main()
