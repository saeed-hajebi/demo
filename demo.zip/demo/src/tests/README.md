How to run tests
----------------
