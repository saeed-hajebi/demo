import pathlib


S3_DATA_FILE = "s3://lse-ml-preprod/data/demo/spam_data.csv"
S3_PROCESSED_FILE = "s3://lse-ml-preprod/data/demo/processed_data.csv"


PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent


## data
DATASET_DIR = PROJECT_ROOT / "data/raw"
TESTING_DATA_FILE = DATASET_DIR / "processed/train"
TRAINING_DATA_FILE = DATASET_DIR / "processed/test"


## models
TRAINED_MODEL_DIR = PROJECT_ROOT / "models"
MODEL_FILE = PROJECT_ROOT.parent / "models/spam_classifier.joblib"
# print(*[sys.path, PROJECT_ROOT, TESTING_DATA_FILE, TRAINING_DATA_FILE], sep='\n')

## variables
TARGET = ""
ID_COLUMNS = []
SNAPSHOT_DATE_COLUMN = ""
JOIN_KEY_COLUMNS = []
FILTER_COLUMNS = []

FEATURES = []
FEATURES_FINAL = []  # Final feature to keep in data
FEATURES_NUMERICAL = []  # Numerical
FEATURES_CATEGORICAL = []  # Categorical
FEATURES_TO_ENCODE = []  # Features to Encode
FEATURES_TEMPORAL = []  # Temporal (date/time)
FEATURES_LOG = []  # Features for Log Transform
FEATURES_DROP = []  # Features to Drop
