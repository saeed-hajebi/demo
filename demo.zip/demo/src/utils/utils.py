import pandas as pd
from sklearn.metrics import accuracy_score, classification_report


def print_classification_report(y_test: pd.DataFrame, y_pred: pd.DataFrame):
    print(classification_report(y_test, y_pred))
    print("Accuracy: {} %".format(100 * accuracy_score(y_test, y_pred)))
