import pandas as pd

# Train, Test Split


# Training a Neural Network Pipeline

from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, classification_report
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_val_score


def train_model(X_train: pd.DataFrame, y_train: pd.DataFrame) -> Pipeline:

    tfidf = TfidfVectorizer(
        strip_accents=None,
        lowercase=False,
        max_features=700,
        ngram_range=(1, 1),
    )

    neural_net_pipeline = Pipeline(
        [
            ("vectorizer", tfidf),
            ("nn", MLPClassifier(hidden_layer_sizes=(700, 700))),
        ]
    )

    neural_net_pipeline.fit(X_train, y_train)

    return neural_net_pipeline
