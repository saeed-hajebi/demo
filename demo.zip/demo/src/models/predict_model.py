import pandas as pd
from sklearn.pipeline import Pipeline

# Testing the Pipeline
def predict_model(model: Pipeline, X_test: pd.DataFrame) -> pd.DataFrame:
    y_pred = model.predict(X_test)
    return y_pred
