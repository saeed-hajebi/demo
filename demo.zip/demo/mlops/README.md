How to run project on PPD & Prod
--------------------------------
